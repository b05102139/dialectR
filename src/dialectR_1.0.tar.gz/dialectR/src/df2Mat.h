#ifndef DF2MAT_H
#define DF2MAT_H

#include <Rcpp.h>
Rcpp::StringMatrix df2Mat(Rcpp::DataFrame x);

#endif
