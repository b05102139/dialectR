#ifndef CHECKVOWELCONSONANT_H
#define CHECKVOWELCONSONANT_H

#include <Rcpp.h>
bool checkVowelConsonant(int w1, int w2);

#endif
