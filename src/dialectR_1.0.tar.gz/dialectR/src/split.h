#ifndef SPLIT_H
#define SPLIT_H

#include <Rcpp.h>

Rcpp::StringVector split(std::string s, std::string delimiter);

#endif
