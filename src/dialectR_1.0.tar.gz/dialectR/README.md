# dialectR
Dialectometry in R
